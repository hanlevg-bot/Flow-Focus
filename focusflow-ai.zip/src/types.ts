/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface MiniTask {
  id: string;
  title: string;
  estimatedMinutes: number;
  isCompleted: boolean;
}

export interface Subtask {
  id: string;
  title: string;
  estimatedMinutes: number;
  deadline: string; // ISO string
  aiTip: string;
  isCompleted: boolean;
  miniTasks: MiniTask[];
}

export interface Task {
  id: string;
  title: string;
  description: string;
  deadline: string; // ISO string
  createdAt: string; // ISO string
  subtasks: Subtask[];
  totalEstimatedMinutes: number;
}

export interface PomodoroSettings {
  workMinutes: number;
  breakMinutes: number;
}
