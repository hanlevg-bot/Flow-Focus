/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Type } from "@google/genai";
import { Task, Subtask } from "../types";
import { v4 as uuidv4 } from "uuid";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export async function breakDownTask(title: string, description: string, deadline: string): Promise<{ subtasks: Subtask[], totalMinutes: number }> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Break down this task into 3-6 ADHD-friendly main milestones (subtasks). 
      Title: ${title}
      Description: ${description}
      Deadline: ${deadline}
      
      CRITICAL: For EACH main milestone, you MUST provide a list of "miniTasks".
      Each miniTask MUST be a tiny, atomic step that takes NO MORE THAN 20 MINUTES to complete.
      The sum of miniTask times should equal the main milestone's estimatedMinutes.
      
      Format the response with actionable titles, micro-time estimates, and practical AI-powered tips for each milestone.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subtasks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  estimatedMinutes: { type: Type.INTEGER },
                  aiTip: { type: Type.STRING },
                  miniTasks: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        title: { type: Type.STRING, description: "Atomic step (max 20 min)" },
                        estimatedMinutes: { type: Type.INTEGER },
                      },
                      required: ["title", "estimatedMinutes"],
                    },
                  },
                },
                required: ["title", "estimatedMinutes", "aiTip", "miniTasks"],
              },
            },
            totalTimeEstimateMinutes: { type: Type.INTEGER },
          },
          required: ["subtasks", "totalTimeEstimateMinutes"],
        },
      },
    });

    const result = JSON.parse(response.text.trim());
    
    const mainDeadlineDate = new Date(deadline);
    const startDate = new Date();
    const totalTimeRange = mainDeadlineDate.getTime() - startDate.getTime();

    const subtasks: Subtask[] = result.subtasks.map((st: any, index: number) => {
      const ratio = (index + 1) / result.subtasks.length;
      const staggeredTime = startDate.getTime() + (totalTimeRange * ratio);
      
      return {
        id: uuidv4(),
        title: st.title,
        estimatedMinutes: st.estimatedMinutes,
        deadline: new Date(staggeredTime).toISOString(),
        aiTip: st.aiTip,
        isCompleted: false,
        miniTasks: st.miniTasks.map((mt: any) => ({
          id: uuidv4(),
          title: mt.title,
          estimatedMinutes: mt.estimatedMinutes,
          isCompleted: false,
        })),
      };
    });

    return {
      subtasks,
      totalMinutes: result.totalTimeEstimateMinutes,
    };
  } catch (error) {
    console.error("AI Task Breakdown failed:", error);
    throw error;
  }
}

const MOTIVATIONAL_QUOTES = [
  "Progress is not linear. Be kind to yourself today.",
  "Your worth is not measured by your productivity.",
  "Small steps still lead to the destination.",
  "It's okay to start small. Just start.",
  "Focus on the next right thing.",
  "Done is better than perfect.",
];

export function getRandomMotivation() {
  return MOTIVATIONAL_QUOTES[Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length)];
}
