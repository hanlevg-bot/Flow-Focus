/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Task, Subtask } from './types';
import TaskForm from './components/TaskForm';
import TaskItem from './components/TaskItem';
import PomodoroTimer from './components/PomodoroTimer';
import { getRandomMotivation } from './services/geminiService';
import { Sparkles, Brain, LayoutDashboard, Target, Zap, Waves } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';

export default function App() {
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('focusflow-tasks');
    return saved ? JSON.parse(saved) : [];
  });
  const [isFocusMode, setIsFocusMode] = useState(false);
  const [motivation, setMotivation] = useState(getRandomMotivation());

  useEffect(() => {
    localStorage.setItem('focusflow-tasks', JSON.stringify(tasks));
  }, [tasks]);

  const handleTaskCreated = (newTask: Task) => {
    setTasks([newTask, ...tasks]);
    setMotivation(getRandomMotivation());
  };

  const handleToggleSubtask = (taskId: string, subtaskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        return {
          ...t,
          subtasks: t.subtasks.map((st) => {
            if (st.id !== subtaskId) return st;
            const newCompleted = !st.isCompleted;
            return {
              ...st,
              isCompleted: newCompleted,
              miniTasks: st.miniTasks.map(mt => ({ ...mt, isCompleted: newCompleted }))
            };
          }),
        };
      })
    );
  };

  const handleToggleMiniTask = (taskId: string, subtaskId: string, miniTaskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        return {
          ...t,
          subtasks: t.subtasks.map((st) => {
            if (st.id !== subtaskId) return st;
            const newMiniTasks = st.miniTasks.map((mt) =>
              mt.id === miniTaskId ? { ...mt, isCompleted: !mt.isCompleted } : mt
            );
            const allMiniCompleted = newMiniTasks.every(mt => mt.isCompleted);
            return {
              ...st,
              miniTasks: newMiniTasks,
              isCompleted: allMiniCompleted
            };
          }),
        };
      })
    );
  };

  const handleDeleteTask = (taskId: string) => {
    if (confirm("Remove this task architecture?")) {
      setTasks(tasks.filter((t) => t.id !== taskId));
    }
  };

  const activeTask = useMemo(() => {
    return tasks.find(t => t.subtasks.some(st => !st.isCompleted));
  }, [tasks]);

  const currentSubtask = useMemo(() => {
    return activeTask?.subtasks.find(st => !st.isCompleted);
  }, [activeTask]);

  return (
    <div className="min-h-screen bg-[#F9F7F2] text-[#344E41] selection:bg-[#A3B18A] selection:text-white pb-20">
      {/* Navigation / Header */}
      <nav className="sticky top-0 z-50 bg-[#F9F7F2]/80 backdrop-blur-md border-b-2 border-[#DAD7CD]/30 px-6 py-4">
        <div className="max-w-5xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-[#344E41] p-2 rounded-xl text-white shadow-lg shadow-emerald-900/20">
              <Waves size={24} strokeWidth={2.5} />
            </div>
            <div>
              <h1 className="font-black text-2xl tracking-tighter leading-none">FocusFlow</h1>
              <span className="text-[10px] font-black text-[#A3B18A] uppercase tracking-[0.3em] ml-0.5">AI Task Manager</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsFocusMode(!isFocusMode)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-black transition-all",
                isFocusMode 
                  ? "bg-[#344E41] text-white shadow-lg" 
                  : "bg-[#DAD7CD]/30 text-[#344E41] hover:bg-[#DAD7CD]/50"
              )}
            >
              {isFocusMode ? <Target size={18} /> : <Zap size={18} />}
              {isFocusMode ? 'Exit Focus' : 'Focus Mode'}
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-5xl mx-auto px-6 pt-12">
        <AnimatePresence mode="wait">
          {!isFocusMode ? (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-12"
            >
              {/* Sidebar: Controls & Stats */}
              <div className="lg:col-span-1 space-y-8">
                <div className="bg-[#A3B18A] rounded-2xl p-6 text-white shadow-xl shadow-emerald-800/10 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <Sparkles size={120} strokeWidth={1} />
                  </div>
                  <h3 className="text-xs font-black uppercase tracking-[0.2em] mb-4 opacity-80">Daily Intention</h3>
                  <p className="text-xl font-bold leading-tight relative z-10">
                    {motivation}
                  </p>
                </div>

                <PomodoroTimer />

                <div className="bg-[#DAD7CD]/20 rounded-2xl p-6 border-2 border-dashed border-[#DAD7CD]">
                  <h4 className="text-[10px] font-black uppercase tracking-widest text-[#A3B18A] mb-4">Mindful Stats</h4>
                  <div className="space-y-4">
                    <div className="flex justify-between items-end">
                      <span className="text-sm font-bold opacity-60">Architectures</span>
                      <span className="text-2xl font-black">{tasks.length}</span>
                    </div>
                    <div className="flex justify-between items-end">
                      <span className="text-sm font-bold opacity-60">Small Wins</span>
                      <span className="text-2xl font-black">
                        {tasks.reduce((acc, t) => acc + t.subtasks.filter(s => s.isCompleted).length, 0)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Main Content: Tasks */}
              <div className="lg:col-span-2">
                <TaskForm onTaskCreated={handleTaskCreated} />
                
                <div className="space-y-12">
                  <AnimatePresence>
                    {tasks.length === 0 ? (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-center py-20 border-2 border-[#DAD7CD] border-dashed rounded-3xl"
                      >
                        <Brain className="mx-auto text-[#DAD7CD] mb-4" size={48} />
                        <p className="text-lg font-bold text-[#A3B18A]">Your mind is a palace, but let's clear the clutter.</p>
                        <p className="text-sm text-[#DAD7CD] mt-2 font-medium">Add a big task to see the AI breakdown magic.</p>
                      </motion.div>
                    ) : (
                      tasks.map((task) => (
                        <TaskItem 
                          key={task.id} 
                          task={task} 
                          onToggleSubtask={handleToggleSubtask}
                          onToggleMiniTask={handleToggleMiniTask}
                          onDelete={handleDeleteTask}
                        />
                      ))
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="focus"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="flex flex-col items-center justify-center min-h-[70vh] max-w-2xl mx-auto text-center"
            >
              <div className="w-full space-y-12">
                <div className="space-y-4">
                  <h2 className="text-[#A3B18A] text-xs font-black uppercase tracking-[0.4em]">Current Objective</h2>
                  {activeTask && currentSubtask ? (
                    <motion.div 
                      layoutId={`title-${activeTask.id}`}
                      className="space-y-6"
                    >
                      <h3 className="text-4xl font-black tracking-tight text-[#344E41]">
                        {currentSubtask.title}
                      </h3>
                      <p className="text-lg text-[#A3B18A] font-medium italic">
                        from: {activeTask.title}
                      </p>
                      <div className="bg-white p-6 rounded-2xl border-2 border-[#A3B18A] shadow-xl">
                        <p className="text-sm font-medium leading-relaxed">
                          <span className="font-black text-[#A3B18A] uppercase text-xs block mb-2 tracking-widest">Focus Strategy</span>
                          {currentSubtask.aiTip}
                        </p>
                      </div>
                    </motion.div>
                  ) : (
                    <div className="py-12">
                      <h3 className="text-3xl font-black text-[#344E41]">All Clarity. No Tasks Left.</h3>
                      <button 
                        onClick={() => setIsFocusMode(false)}
                        className="mt-6 text-[#A3B18A] font-bold underline"
                      >
                        Return to Planning
                      </button>
                    </div>
                  )}
                </div>

                <div className="max-w-sm mx-auto w-full">
                  <PomodoroTimer className="shadow-2xl shadow-emerald-900/10" />
                </div>
                
                {activeTask && currentSubtask && (
                  <button
                    onClick={() => handleToggleSubtask(activeTask.id, currentSubtask.id)}
                    className="flex items-center gap-3 px-8 py-5 bg-[#344E41] text-white rounded-2xl font-black text-xl hover:scale-105 active:scale-95 transition-all shadow-xl shadow-[#344E41]/20"
                  >
                    Done for Now
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

