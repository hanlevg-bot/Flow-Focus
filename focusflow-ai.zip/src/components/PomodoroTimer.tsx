/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Coffee, Brain } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface PomodoroTimerProps {
  initialMinutes?: number;
  onComplete?: () => void;
  className?: string;
}

export default function PomodoroTimer({ initialMinutes = 25, onComplete, className }: PomodoroTimerProps) {
  const [seconds, setSeconds] = useState(initialMinutes * 60);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'work' | 'break'>('work');
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isActive && seconds > 0) {
      timerRef.current = setInterval(() => {
        setSeconds((prev) => prev - 1);
      }, 1000);
    } else if (seconds === 0) {
      setIsActive(false);
      onComplete?.();
      handleModeSwitch();
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, seconds]);

  const handleModeSwitch = () => {
    if (mode === 'work') {
      setMode('break');
      setSeconds(5 * 60);
    } else {
      setMode('work');
      setSeconds(25 * 60);
    }
  };

  const toggleTimer = () => setIsActive(!isActive);
  
  const resetTimer = () => {
    setIsActive(false);
    setSeconds(mode === 'work' ? initialMinutes * 60 : 5 * 60);
  };

  const minutesDisplay = Math.floor(seconds / 60);
  const secondsDisplay = seconds % 60;

  return (
    <div className={cn("bg-white border-2 border-[#A3B18A] rounded-2xl p-6 shadow-sm", className)}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 text-[#344E41]">
          {mode === 'work' ? <Brain size={20} /> : <Coffee size={20} />}
          <span className="font-semibold uppercase tracking-wider text-xs">
            {mode === 'work' ? 'Focus Session' : 'Take a Breath'}
          </span>
        </div>
        <div className="text-[#A3B18A] text-xs font-medium">
          {isActive ? 'Live' : 'Paused'}
        </div>
      </div>

      <div className="text-6xl font-black text-[#344E41] tracking-tighter mb-6 font-mono text-center">
        {minutesDisplay.toString().padStart(2, '0')}:{secondsDisplay.toString().padStart(2, '0')}
      </div>

      <div className="flex justify-center gap-3">
        <button
          onClick={toggleTimer}
          className={cn(
            "flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all duration-200",
            isActive 
              ? "bg-[#DAD7CD] text-[#344E41] hover:bg-[#A3B18A]/20" 
              : "bg-[#344E41] text-white hover:scale-105 shadow-md shadow-emerald-900/10"
          )}
        >
          {isActive ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />}
          {isActive ? 'Pause' : 'Start'}
        </button>
        
        <button
          onClick={resetTimer}
          className="p-3 bg-[#F9F7F2] text-[#A3B18A] border-2 border-[#A3B18A]/20 rounded-xl hover:bg-[#A3B18A]/10 transition-colors"
          title="Reset"
        >
          <RotateCcw size={20} />
        </button>
      </div>
    </div>
  );
}
