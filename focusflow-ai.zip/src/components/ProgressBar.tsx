/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

interface ProgressBarProps {
  progress: number; // 0 to 1
  className?: string;
  showPercentage?: boolean;
}

export default function ProgressBar({ progress, className, showPercentage = false }: ProgressBarProps) {
  const percentage = Math.round(progress * 100);

  return (
    <div className={cn("w-full", className)}>
      <div className="h-4 w-full bg-[#DAD7CD]/50 rounded-full overflow-hidden border-2 border-[#DAD7CD]">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ type: "spring", stiffness: 40, damping: 10 }}
          className="h-full bg-[#A3B18A] relative"
        >
          {progress > 0.1 && (
             <motion.div 
               animate={{ x: [0, 10, 0] }}
               transition={{ repeat: Infinity, duration: 2 }}
               className="absolute inset-0 bg-linear-to-r from-transparent via-white/20 to-transparent"
             />
          )}
        </motion.div>
      </div>
      {showPercentage && (
        <div className="mt-2 text-right">
          <span className="text-xs font-bold text-[#A3B18A] tracking-widest uppercase">
            {percentage}% Complete
          </span>
        </div>
      )}
    </div>
  );
}
