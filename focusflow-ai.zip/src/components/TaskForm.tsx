/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, Sparkles, Loader2 } from 'lucide-react';
import { breakDownTask } from '../services/geminiService';
import { Task } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { cn } from '../lib/utils';

interface TaskFormProps {
  onTaskCreated: (task: Task) => void;
}

export default function TaskForm({ onTaskCreated }: TaskFormProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !deadline) return;

    setIsLoading(true);
    try {
      const { subtasks, totalMinutes } = await breakDownTask(title, description, deadline);
      
      const newTask: Task = {
        id: uuidv4(),
        title,
        description,
        deadline,
        createdAt: new Date().toISOString(),
        subtasks,
        totalEstimatedMinutes: totalMinutes,
      };

      onTaskCreated(newTask);
      setTitle('');
      setDescription('');
      setDeadline('');
    } catch (error) {
      alert("Failed to break down task. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form 
      onSubmit={handleSubmit}
      className="bg-white border-2 border-[#A3B18A] rounded-2xl p-6 shadow-sm mb-8"
    >
      <div className="flex items-center gap-2 mb-6">
        <div className="bg-[#A3B18A]/20 p-2 rounded-lg">
          <Sparkles className="text-[#344E41]" size={20} />
        </div>
        <h2 className="text-xl font-bold text-[#344E41]">Start a New Goal</h2>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-[#344E41] uppercase tracking-widest mb-1 ml-1">
            Task Title
          </label>
          <input
            type="text"
            placeholder="e.g. Write university essay on climate change"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            disabled={isLoading}
            className="w-full px-4 py-3 rounded-xl border-2 border-[#DAD7CD] focus:border-[#A3B18A] focus:ring-0 outline-hidden transition-all placeholder:text-[#A3B18A]/50 bg-[#F9F7F2]"
            required
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-[#344E41] uppercase tracking-widest mb-1 ml-1">
            Extra Details (Optional)
          </label>
          <textarea
            placeholder="Any context to help the AI break it down..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            disabled={isLoading}
            className="w-full px-4 py-3 rounded-xl border-2 border-[#DAD7CD] focus:border-[#A3B18A] focus:ring-0 outline-hidden transition-all placeholder:text-[#A3B18A]/50 bg-[#F9F7F2] min-h-[80px]"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-[#344E41] uppercase tracking-widest mb-1 ml-1">
            Main Deadline
          </label>
          <input
            type="datetime-local"
            value={deadline}
            onChange={(e) => setDeadline(e.target.value)}
            disabled={isLoading}
            className="w-full px-4 py-3 rounded-xl border-2 border-[#DAD7CD] focus:border-[#A3B18A] focus:ring-0 outline-hidden transition-all bg-[#F9F7F2]"
            required
          />
        </div>

        <button
          type="submit"
          disabled={isLoading || !title || !deadline}
          className={cn(
            "w-full flex items-center justify-center gap-2 py-4 rounded-xl font-black text-lg transition-all active:scale-95 shadow-md",
            isLoading 
              ? "bg-[#DAD7CD] text-[#344E41] cursor-not-allowed" 
              : "bg-[#344E41] text-white hover:bg-[#3A5A40] hover:shadow-lg shadow-[#344E41]/10"
          )}
        >
          {isLoading ? (
            <>
              <Loader2 className="animate-spin" size={24} />
              AI is breaking it down...
            </>
          ) : (
            <>
              <Plus size={24} strokeWidth={3} />
              Create Task Architecture
            </>
          )}
        </button>
      </div>
    </form>
  );
}
