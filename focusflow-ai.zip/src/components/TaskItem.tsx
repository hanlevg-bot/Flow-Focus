/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Task, Subtask } from '../types';
import { CheckCircle2, Circle, Clock, Info, ExternalLink, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import ProgressBar from './ProgressBar';

interface TaskItemProps {
  task: Task;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  onToggleMiniTask: (taskId: string, subtaskId: string, miniTaskId: string) => void;
  onDelete?: (taskId: string) => void;
}

export default function TaskItem({ task, onToggleSubtask, onToggleMiniTask, onDelete }: TaskItemProps) {
  const completedCount = task.subtasks.filter((s) => s.isCompleted).length;
  const progress = task.subtasks.length > 0 ? completedCount / task.subtasks.length : 0;
  const isFullyCompleted = progress === 1;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "bg-white border-2 rounded-2xl overflow-hidden transition-all duration-300",
        isFullyCompleted ? "border-[#A3B18A]/20 opacity-70" : "border-[#A3B18A] shadow-lg shadow-[#A3B18A]/5"
      )}
    >
      {/* Header */}
      <div className="p-6 border-b border-[#DAD7CD]/50">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className={cn(
              "text-2xl font-black text-[#344E41] tracking-tight leading-tight mb-2",
              isFullyCompleted && "line-through text-[#A3B18A]"
            )}>
              {task.title}
            </h3>
            <div className="flex flex-wrap gap-4 text-xs font-bold text-[#A3B18A] uppercase tracking-widest">
              <span className="flex items-center gap-1.5 ">
                <Clock size={14} />
                ~{task.totalEstimatedMinutes} mins total
              </span>
              <span className="flex items-center gap-1.5">
                <Calendar size={14} />
                Due {format(new Date(task.deadline), 'MMM d, h:mm a')}
              </span>
            </div>
          </div>
          {onDelete && (
            <button 
              onClick={() => onDelete(task.id)}
              className="p-2 text-[#DAD7CD] hover:text-[#FF4D4D] transition-colors"
            >
              <ExternalLink size={20} className="rotate-45" />
            </button>
          )}
        </div>
        
        {task.description && (
          <p className="text-[#344E41]/70 text-sm mb-6 max-w-2xl font-medium leading-relaxed italic border-l-4 border-[#DAD7CD] pl-4">
            "{task.description}"
          </p>
        )}

        <ProgressBar progress={progress} showPercentage />
      </div>

      {/* Subtasks */}
      <div className="p-6 space-y-4">
        <h4 className="text-[10px] font-black text-[#344E41]/40 uppercase tracking-[0.2em] mb-2">
          Milestones & Mini-Tasks (Max 20 mins each)
        </h4>
        <div className="space-y-4">
          {task.subtasks.map((st) => (
            <div key={st.id} className="space-y-2">
              <motion.button
                whileHover={{ x: 4 }}
                onClick={() => onToggleSubtask(task.id, st.id)}
                className={cn(
                  "w-full text-left p-4 rounded-xl border-2 transition-all group flex gap-4 items-start",
                  st.isCompleted 
                    ? "bg-[#F9F7F2] border-transparent" 
                    : "bg-white border-[#DAD7CD] hover:border-[#A3B18A] shadow-sm hover:shadow-md"
                )}
              >
                <div className="mt-0.5">
                  {st.isCompleted ? (
                    <CheckCircle2 className="text-[#A3B18A]" size={24} />
                  ) : (
                    <Circle className="text-[#DAD7CD] group-hover:text-[#A3B18A]" size={24} />
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start mb-1">
                    <span className={cn(
                      "text-lg font-black leading-none",
                      st.isCompleted ? "text-[#A3B18A] line-through" : "text-[#344E41]"
                    )}>
                      {st.title}
                    </span>
                    <span className="text-[10px] font-black text-[#A3B18A] uppercase whitespace-nowrap bg-[#DAD7CD]/20 px-2 py-0.5 rounded-full">
                      {st.estimatedMinutes}m
                    </span>
                  </div>
                  
                  {!st.isCompleted && (
                    <div className="mt-3 flex items-start gap-2 bg-[#F9F7F2] p-3 rounded-lg border-l-4 border-[#A3B18A]">
                      <div className="mt-0.5 text-[#A3B18A]">
                        <Info size={14} />
                      </div>
                      <p className="text-xs text-[#344E41]/80 leading-snug font-medium">
                        <span className="font-bold text-[#A3B18A] mr-1 uppercase text-[9px]">AI Tip:</span>
                        {st.aiTip}
                      </p>
                    </div>
                  )}
                </div>
              </motion.button>

              {/* Mini Tasks */}
              {!st.isCompleted && st.miniTasks && st.miniTasks.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 ml-10">
                  {st.miniTasks.map(mt => (
                    <button
                      key={mt.id}
                      onClick={() => onToggleMiniTask(task.id, st.id, mt.id)}
                      className={cn(
                        "text-left p-3 rounded-lg border flex items-center gap-3 transition-colors",
                        mt.isCompleted 
                          ? "bg-[#F9F7F2] border-transparent text-[#A3B18A]" 
                          : "bg-white border-[#DAD7CD] hover:border-[#A3B18A] text-[#344E41]"
                      )}
                    >
                      {mt.isCompleted ? <CheckCircle2 size={16} /> : <Circle size={16} />}
                      <div className="flex-1 min-w-0">
                        <p className={cn("text-xs font-bold leading-tight", mt.isCompleted && "line-through")}>
                          {mt.title}
                        </p>
                        <span className="text-[8px] font-black uppercase tracking-tighter opacity-40">
                          {mt.estimatedMinutes} min
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
